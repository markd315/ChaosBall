export host=zanzalaz.com
java -cp Chaosball.jar client.ChaosballWindow